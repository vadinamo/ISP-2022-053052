from distutils.core import setup

setup(name='lab2_serializer',
      version='1.0',
      description='serializer',
      author='Vadim Yurev',
      author_email='vadinamo@gmail.com',
      url='',
      packages=['serializer'],
      )
